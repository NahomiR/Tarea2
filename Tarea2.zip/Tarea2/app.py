

from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if username and username[0].isupper() and password.isalnum():
            # Redirige a la página de éxito si se cumplen las condiciones
            return redirect(url_for('login_success'))

    return render_template('login.html')

@app.route('/login_success')
def login_success():
    return 'Login successful!'

if __name__ == '__main__':
    app.run(debug=True)
